# Questify — Runpod Flash Handler

This is the serverless backend for Questify, deployed as a Runpod Flash endpoint.

## What it does

1. Accepts `{ "goal": "..." }` as input
2. Calls You.com Search API to find relevant learning resources
3. Builds an LLM prompt and calls OpenAI GPT-4o-mini
4. Returns a structured quest JSON

## Response schema

```json
{
  "title": "",
  "difficulty": "Beginner | Intermediate | Advanced",
  "estimated_time": "",
  "objectives": [],
  "boss_battle": "",
  "xp": 0,
  "resources": []
}
```

## Deploy to Runpod Flash

1. Build and push the Docker image:
   ```bash
   docker build -t your-registry/questify-flash:latest .
   docker push your-registry/questify-flash:latest
   ```

2. Create a Runpod Serverless endpoint using your image.

3. Set these environment variables on the endpoint:
   - `YOU_API_KEY` — You.com Search API key
   - `OPENAI_API_KEY` — OpenAI API key

4. Copy the endpoint ID and set `RUNPOD_ENDPOINT_ID` in your app environment.

## Local testing (without Runpod)

```bash
pip install -r requirements.txt
YOU_API_KEY=... OPENAI_API_KEY=... python -c "
from handler import generate_quest
import json
print(json.dumps(generate_quest('Learn LangGraph'), indent=2))
"
```
