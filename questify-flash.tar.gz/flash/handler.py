import runpod
import os
import json
import re
import requests

YOU_API_KEY = os.environ.get("YOU_API_KEY", "")

YOU_SEARCH_URL = "https://api.you.com/v1/search"

DIFFICULTY_SIGNALS = {
    "Beginner": [
        "beginner", "intro", "introduction", "getting started", "basics",
        "fundamentals", "overview", "101", "first steps", "quickstart",
        "starter", "learn", "tutorial for beginners", "simple", "easy",
    ],
    "Advanced": [
        "advanced", "deep dive", "internals", "architecture", "production",
        "optimization", "performance", "expert", "mastery", "in-depth",
        "under the hood", "enterprise", "large scale", "complex",
    ],
}

DOMAIN_RESOURCE_TYPES = {
    "youtube.com": "video",
    "youtu.be": "video",
    "udemy.com": "course",
    "coursera.org": "course",
    "edx.org": "course",
    "pluralsight.com": "course",
    "linkedin.com/learning": "course",
    "deeplearning.ai": "course",
    "github.com": "docs",
    "docs.": "docs",
    "documentation": "docs",
    "readthedocs.io": "docs",
    "arxiv.org": "article",
    "medium.com": "article",
    "towardsdatascience.com": "article",
    "dev.to": "article",
    "substack.com": "article",
    "blog": "article",
}

TIME_ESTIMATES = {
    "Beginner": "4–6 hours",
    "Intermediate": "1–2 weeks",
    "Advanced": "3–4 weeks",
}

XP_BY_DIFFICULTY = {
    "Beginner": 300,
    "Intermediate": 700,
    "Advanced": 1500,
}


def search_you(query: str, num_results: int = 10) -> list[dict]:
    """Fetch web search results from You.com API."""
    if not YOU_API_KEY:
        return []
    try:
        resp = requests.get(
            YOU_SEARCH_URL,
            params={"query": query, "num_web_results": num_results},
            headers={"X-API-Key": YOU_API_KEY},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
        hits = data.get("results", {}).get("web", [])
        results = []
        for hit in hits:
            results.append({
                "title": hit.get("title", ""),
                "url": hit.get("url", ""),
                "description": hit.get("description", ""),
                "snippets": hit.get("snippets", []),
            })
        return results
    except Exception as e:
        print(f"You.com search error: {e}")
        return []


def classify_resource_type(url: str, title: str) -> str:
    url_lower = url.lower()
    title_lower = title.lower()
    for domain, rtype in DOMAIN_RESOURCE_TYPES.items():
        if domain in url_lower:
            return rtype
    if "video" in title_lower or "watch" in title_lower:
        return "video"
    if "course" in title_lower or "learn" in title_lower:
        return "course"
    if "doc" in title_lower or "reference" in title_lower or "api" in title_lower:
        return "docs"
    return "article"


def detect_difficulty(goal: str, results: list[dict]) -> str:
    text = goal.lower()
    for result in results[:3]:
        text += " " + result.get("title", "").lower()
        text += " " + result.get("description", "").lower()

    adv_score = sum(1 for kw in DIFFICULTY_SIGNALS["Advanced"] if kw in text)
    beg_score = sum(1 for kw in DIFFICULTY_SIGNALS["Beginner"] if kw in text)

    if adv_score > beg_score:
        return "Advanced"
    if beg_score > 0:
        return "Beginner"
    return "Intermediate"


def extract_topic_words(goal: str) -> list[str]:
    """Pull meaningful words from the goal string."""
    stop = {"a", "an", "the", "to", "how", "learn", "understand", "use", "build",
            "create", "make", "get", "set", "up", "with", "using", "via", "for",
            "and", "or", "of", "in", "on", "at", "from", "by"}
    words = re.findall(r"[A-Za-z][A-Za-z0-9+#.\-]*", goal)
    return [w for w in words if w.lower() not in stop and len(w) > 1]


def build_objectives(goal: str, results: list[dict], difficulty: str) -> list[str]:
    """Generate 3–5 specific, actionable learning objectives from search snippets."""
    topics = extract_topic_words(goal)
    topic_str = " / ".join(topics[:3]) if topics else "the subject"

    prefix_map = {
        "Beginner": ["Understand", "Explain", "Identify", "Set up", "Run your first"],
        "Intermediate": ["Build", "Implement", "Apply", "Integrate", "Configure"],
        "Advanced": ["Design", "Optimize", "Deploy", "Debug", "Architect"],
    }
    prefixes = prefix_map.get(difficulty, prefix_map["Intermediate"])

    objectives = []

    # Pull key concepts from snippets
    concept_sentences = []
    for r in results[:5]:
        for s in r.get("snippets", [])[:2]:
            sentences = re.split(r"[.!?]", s)
            for sent in sentences:
                sent = sent.strip()
                if 20 < len(sent) < 120 and any(t.lower() in sent.lower() for t in topics):
                    concept_sentences.append(sent)

    if concept_sentences:
        objectives.append(f"{prefixes[0]} the core concepts of {topic_str}: {concept_sentences[0][:80].rstrip('.,;')}.")
    else:
        objectives.append(f"{prefixes[0]} the core concepts and architecture of {topic_str}.")

    if len(prefixes) > 1:
        objectives.append(f"{prefixes[1]} a working project using {topic_str} from scratch.")

    if len(concept_sentences) > 1:
        objectives.append(f"{prefixes[min(2, len(prefixes)-1)]} {concept_sentences[1][:80].rstrip('.,;').lower()}.")
    elif len(prefixes) > 2:
        objectives.append(f"{prefixes[2]} real-world workflows and patterns with {topic_str}.")

    objectives.append(f"Review and consolidate learning through hands-on practice and the boss battle challenge.")

    return objectives[:4]


def build_boss_battle(goal: str, difficulty: str, topics: list[str]) -> str:
    topic_str = " and ".join(topics[:2]) if topics else "the topic"
    battles = {
        "Beginner": f"Build a minimal end-to-end demo using {topic_str} that you can explain to a peer — document what it does and why each piece matters.",
        "Intermediate": f"Implement a complete {topic_str} application with at least two real-world features, write a short write-up of design decisions, and share it publicly (GitHub, blog, etc.).",
        "Advanced": f"Design and deploy a production-ready {topic_str} system: handle edge cases, write integration tests, and present a performance analysis comparing at least two architectural approaches.",
    }
    return battles.get(difficulty, battles["Intermediate"])


def build_quest(goal: str, results: list[dict]) -> dict:
    difficulty = detect_difficulty(goal, results)
    topics = extract_topic_words(goal)
    topic_str = " ".join(topics[:3]) if topics else goal

    # Title
    title_prefixes = {
        "Beginner": "Getting Started with",
        "Intermediate": "Building with",
        "Advanced": "Mastering",
    }
    title = f"{title_prefixes[difficulty]} {topic_str}"

    # Resources — deduplicate by URL, prefer varied source types
    seen_urls = set()
    resources = []
    for r in results:
        url = r.get("url", "")
        if not url or url in seen_urls:
            continue
        seen_urls.add(url)
        rtype = classify_resource_type(url, r.get("title", ""))
        resources.append({
            "title": r["title"],
            "url": url,
            "type": rtype,
        })
        if len(resources) >= 7:
            break

    objectives = build_objectives(goal, results, difficulty)
    boss_battle = build_boss_battle(goal, difficulty, topics)

    return {
        "title": title,
        "difficulty": difficulty,
        "estimated_time": TIME_ESTIMATES[difficulty],
        "objectives": objectives,
        "boss_battle": boss_battle,
        "xp": XP_BY_DIFFICULTY[difficulty],
        "resources": resources,
    }


def generate_quest(goal: str) -> dict:
    # Search twice: once for the core topic, once for tutorials/resources
    results_main = search_you(goal, num_results=8)
    results_tutorials = search_you(f"{goal} tutorial guide resources", num_results=5)

    # Merge, deduplicate by URL
    seen = set()
    all_results = []
    for r in results_main + results_tutorials:
        url = r.get("url", "")
        if url and url not in seen:
            seen.add(url)
            all_results.append(r)

    if not all_results:
        return {
            "title": f"Learning Quest: {goal}",
            "difficulty": "Intermediate",
            "estimated_time": "1–2 weeks",
            "objectives": [
                f"Understand the fundamentals of {goal}.",
                f"Build a hands-on project using {goal}.",
                "Review and consolidate your learning.",
            ],
            "boss_battle": f"Build and document a working {goal} project end to end.",
            "xp": 500,
            "resources": [],
        }

    return build_quest(goal, all_results)


def handler(job):
    """Runpod Flash handler — entry point for serverless execution."""
    job_input = job.get("input", {})
    goal = job_input.get("goal", "").strip()

    if not goal:
        return {"error": "Missing required field: goal"}

    try:
        return generate_quest(goal)
    except Exception as e:
        return {"error": f"Unexpected error: {str(e)}"}


if __name__ == "__main__":
    runpod.serverless.start({"handler": handler})
